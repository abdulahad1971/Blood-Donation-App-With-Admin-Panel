<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'db_connect.php'; // DB কানেকশন

// POST থেকে ডাটা নেওয়া
$name         = isset($_POST['name']) ? trim($_POST['name']) : "";
$phone        = isset($_POST['phone']) ? trim($_POST['phone']) : "";
$blood_group  = isset($_POST['blood_group']) ? trim($_POST['blood_group']) : "";
$district     = isset($_POST['district']) ? trim($_POST['district']) : "";
$address      = isset($_POST['address']) ? trim($_POST['address']) : "";
$is_donor     = isset($_POST['is_donor']) ? intval($_POST['is_donor']) : 0;
$profile_base64 = isset($_POST['profile_image']) ? $_POST['profile_image'] : "";

// ভ্যালিডেশন
if ($name == "" || $phone == "") {
  http_response_code(400);
  echo json_encode(["status" => false, "message" => "নাম এবং ফোন অবশ্যই দিতে হবে।"]);
  exit();
}

// ইউজার খুঁজে বের করা
$sql_check = "SELECT * FROM users WHERE phone = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("s", $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
  http_response_code(404);
  echo json_encode(["status" => false, "message" => "ইউজার পাওয়া যায়নি।"]);
  exit();
}

// প্রোফাইল ইমেজ আপলোড (যদি থাকে)
$profile_image_path = null;

if (!empty($profile_base64)) {
  $image_data = base64_decode($profile_base64);
  $image_name = "profile_" . $phone . "_" . time() . ".jpg";
  $upload_dir = "uploads/profile_images/";

  if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
  }

  $file_path = $upload_dir . $image_name;

  if (file_put_contents($file_path, $image_data)) {
    $profile_image_path = $file_path;
  } else {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "ছবি আপলোড ব্যর্থ।"]);
    exit();
  }
}

// ইউজার আপডেট
if ($profile_image_path) {
  $sql_update = "UPDATE users SET name = ?, blood_group = ?, district = ?, address = ?, is_donor = ?, profile_image = ? WHERE phone = ?";
  $stmt_update = $conn->prepare($sql_update);
  $stmt_update->bind_param("ssssiss", $name, $blood_group, $district, $address, $is_donor, $profile_image_path, $phone);
} else {
  $sql_update = "UPDATE users SET name = ?, blood_group = ?, district = ?, address = ?, is_donor = ? WHERE phone = ?";
  $stmt_update = $conn->prepare($sql_update);
  $stmt_update->bind_param("ssssis", $name, $blood_group, $district, $address, $is_donor, $phone);
}

if ($stmt_update->execute()) {
  echo json_encode(["status" => true, "message" => "প্রোফাইল সফলভাবে আপডেট হয়েছে"]);
} else {
  http_response_code(500);
  echo json_encode(["status" => false, "message" => "আপডেট করতে সমস্যা হয়েছে"]);
}

$conn->close();
