<?php
include 'db_connect.php';

$sql = "SELECT text FROM marquee_text ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);

$response = array();

if ($result && mysqli_num_rows($result) > 0) {
  $row = mysqli_fetch_assoc($result);
  $response['success'] = true;
  $response['text'] = $row['text'];
} else {
  $response['success'] = false;
  $response['message'] = 'No marquee text found.';
}

echo json_encode($response);
