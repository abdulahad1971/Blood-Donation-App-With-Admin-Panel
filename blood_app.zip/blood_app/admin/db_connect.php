<?php
$host = "localhost";
$user = "fahimhas_fahim_bapp";
$pass = "5*7Vm+CtdRYFrLsg";
$dbname = "fahimhas_fahim_blood";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
  die("Database Connection Failed: " . $conn->connect_error);
}
