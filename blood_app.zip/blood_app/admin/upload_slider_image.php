<?php
include 'db_connect.php';

$uploadDir = 'uploads/slider/';
if (!is_dir($uploadDir)) {
  mkdir($uploadDir, 0777, true);
}

if (isset($_POST['image']) && isset($_POST['filename'])) {
  $base64Image = $_POST['image'];
  $filename = basename($_POST['filename']);
  $filePath = $uploadDir . $filename;

  if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
    $base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
  }

  $imageData = base64_decode($base64Image);

  if ($imageData === false) {
    echo json_encode(["success" => false, "message" => "❌ Base64 decode failed"]);
    exit;
  }

  if (file_put_contents($filePath, $imageData)) {
    $escapedPath = mysqli_real_escape_string($conn, $filePath);
    $sql = "INSERT INTO image_slider (image_url) VALUES ('$escapedPath')";
    if (mysqli_query($conn, $sql)) {
      echo json_encode(["success" => true, "message" => "✅ Image uploaded successfully"]);
    } else {
      echo json_encode([
        "success" => false,
        "message" => "❌ Database insert failed: " . mysqli_error($conn)
      ]);
    }
  } else {
    echo json_encode(["success" => false, "message" => "❌ Failed to save file"]);
  }
} else {
  echo json_encode(["success" => false, "message" => "❌ Image data or filename missing"]);
}
