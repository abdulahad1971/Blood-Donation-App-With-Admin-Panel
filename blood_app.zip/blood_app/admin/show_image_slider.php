<?php
include 'db_connect.php';

$sql = "SELECT image_url FROM image_slider ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

$response = array();

if ($result) {
  $images = array();
  while ($row = mysqli_fetch_assoc($result)) {
    $images[] = $row['image_url'];
  }
  $response['success'] = true;
  $response['images'] = $images;
} else {
  $response['success'] = false;
  $response['message'] = "Database error";
}

echo json_encode($response);
