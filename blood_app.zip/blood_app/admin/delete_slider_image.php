<?php
include 'db_connect.php';

if (isset($_POST['filename'])) {
  $filename = basename($_POST['filename']);
  $filepath = "uploads/slider/" . $filename;

  // Delete file from folder
  if (file_exists($filepath)) {
    unlink($filepath); // delete physical file
  }

  // Delete from DB
  $sql = "DELETE FROM image_slider WHERE image_url LIKE '%$filename%'";
  if (mysqli_query($conn, $sql)) {
    echo json_encode(["success" => true, "message" => "Deleted"]);
  } else {
    echo json_encode(["success" => false, "message" => "DB delete failed"]);
  }
} else {
  echo json_encode(["success" => false, "message" => "Filename missing"]);
}
