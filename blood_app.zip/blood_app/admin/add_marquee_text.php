<?php
header('Content-Type: application/json'); // ✅ VERY IMPORTANT

include 'db_connect.php';

if (isset($_POST['text'])) {
  $text = mysqli_real_escape_string($conn, $_POST['text']);

  $sql = "INSERT INTO marquee_text (text) VALUES ('$text')";
  if (mysqli_query($conn, $sql)) {
    echo json_encode(['success' => true, 'message' => 'Text added successfully']);
  } else {
    echo json_encode(['success' => false, 'message' => 'Failed to insert']);
  }
} else {
  echo json_encode(['success' => false, 'message' => 'Text missing']);
}
