<?php
include 'db_connect.php';

if (isset($_POST['id'])) {
  $id = $_POST['id'];

  $sql = "DELETE FROM users WHERE id = '$id'";
  if (mysqli_query($conn, $sql)) {
    echo json_encode(["success" => true]);
  } else {
    echo json_encode(["success" => false]);
  }
} else {
  echo json_encode(["success" => false]);
}
