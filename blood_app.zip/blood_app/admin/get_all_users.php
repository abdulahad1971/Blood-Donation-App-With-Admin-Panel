<?php
include 'db_connect.php'; // DB কানেকশন

$sql = "SELECT id, name, phone, blood_group, district, address,is_donor, profile_image FROM users ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

$response = array();

if ($result && mysqli_num_rows($result) > 0) {
  $response['success'] = true;
  $response['users'] = array();

  while ($row = mysqli_fetch_assoc($result)) {
    // শুধুমাত্র রিলেটিভ পাথ রাখুন
    $row['profile_image'] = $row['profile_image'];
    $response['users'][] = $row;
  }
} else {
  $response['success'] = false;
  $response['message'] = "কোনো ইউজার পাওয়া যায়নি!";
}

header('Content-Type: application/json');
echo json_encode($response);
