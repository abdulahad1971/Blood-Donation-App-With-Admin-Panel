CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    phone VARCHAR(20) UNIQUE,
    password VARCHAR(255),
    blood_group VARCHAR(10),
    district VARCHAR(50),
    address TEXT,
    is_donor TINYINT(1) DEFAULT 0,
    profile_image VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE marquee_text (
    id INT AUTO_INCREMENT PRIMARY KEY,
    text VARCHAR(1000) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE image_slider (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_url VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE blood_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id TEXT,
    name VARCHAR(100),
    phone VARCHAR(20),
    blood_group VARCHAR(10),
    district VARCHAR(100),
    address TEXT,
    problem TEXT,
    image TEXT,
    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
);

