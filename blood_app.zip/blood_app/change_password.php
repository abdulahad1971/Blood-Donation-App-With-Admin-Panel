<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'db_connect.php';

$phone = $_POST['phone'] ?? '';
$old_password = $_POST['old_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';

if (!$phone || !$old_password || !$new_password) {
  echo json_encode(['status' => false, 'message' => 'সব তথ্য দিতে হবে।']);
  exit();
}

// ইউজার পাওয়া যাচ্ছে কিনা চেক
$sql = "SELECT password FROM users WHERE phone = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo json_encode(['status' => false, 'message' => 'ইউজার পাওয়া যায়নি।']);
  exit();
}

$user = $result->fetch_assoc();
$hashed_password = $user['password'];

// পুরানো পাসওয়ার্ড যাচাই
if (!password_verify($old_password, $hashed_password)) {
  echo json_encode(['status' => false, 'message' => 'পুরানো পাসওয়ার্ড ভুল।']);
  exit();
}

// নতুন পাসওয়ার্ড হ্যাশ করো
$new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

// পাসওয়ার্ড আপডেট
$sql_update = "UPDATE users SET password = ? WHERE phone = ?";
$stmt_update = $conn->prepare($sql_update);
$stmt_update->bind_param("ss", $new_hashed_password, $phone);

if ($stmt_update->execute()) {
  echo json_encode(['status' => true, 'message' => 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে।']);
} else {
  echo json_encode(['status' => false, 'message' => 'আপডেট করতে সমস্যা হয়েছে।']);
}

$conn->close();
