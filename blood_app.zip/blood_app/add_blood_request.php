<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php';

header("Content-Type: application/json");

$response = array();

file_put_contents('debug_log.txt', "POST Data: " . print_r($_POST, true) . "\n", FILE_APPEND);

if (
  isset($_POST['user_id']) &&
  isset($_POST['name']) &&
  isset($_POST['phone']) &&
  isset($_POST['blood_group']) &&
  isset($_POST['district']) &&
  isset($_POST['address']) &&
  isset($_POST['problem']) &&
  isset($_POST['image'])
) {
  $user_id     = mysqli_real_escape_string($conn, $_POST['user_id']);
  $name        = mysqli_real_escape_string($conn, $_POST['name']);
  $phone       = mysqli_real_escape_string($conn, $_POST['phone']);
  $blood_group = mysqli_real_escape_string($conn, $_POST['blood_group']);
  $district    = mysqli_real_escape_string($conn, $_POST['district']);
  $address     = mysqli_real_escape_string($conn, $_POST['address']);
  $problem     = mysqli_real_escape_string($conn, $_POST['problem']);
  $image       = $_POST['image']; // Base64 encoded

  $image_name = uniqid("img_") . ".jpg";
  $upload_path = "uploads/" . $image_name;

  if (file_put_contents($upload_path, base64_decode($image))) {
    $sql = "INSERT INTO blood_requests (user_id, name, phone, blood_group, district, address, problem, image)
            VALUES ('$user_id', '$name', '$phone', '$blood_group', '$district', '$address', '$problem', '$image_name')";

    if (mysqli_query($conn, $sql)) {
      $response['success'] = true;
      $response['message'] = "রক্তের অনুরোধ সফলভাবে যুক্ত হয়েছে।";
    } else {
      $error = mysqli_error($conn);
      file_put_contents('debug_log.txt', "MySQL Error: $error\n", FILE_APPEND);
      $response['success'] = false;
      $response['message'] = "ডেটা ইনসার্ট করতে সমস্যা হয়েছে: " . $error;
    }
  } else {
    $response['success'] = false;
    $response['message'] = "ছবি আপলোড ব্যর্থ হয়েছে।";
  }
} else {
  $response['success'] = false;
  $response['message'] = "সব ফিল্ড প্রদান করুন।";
}

echo json_encode($response);
