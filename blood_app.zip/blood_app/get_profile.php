<?php
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['phone']) || empty($_GET['phone'])) {
  echo json_encode(["status" => "error", "message" => "Phone required"]);
  exit;
}

$phone = $_GET['phone'];  // GET method এ নিলাম

$sql = "SELECT * FROM users WHERE phone = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo json_encode([
    "status" => "success",
    "data" => [
      "name" => $row['name'],
      "blood_group" => $row['blood_group'],
      "district" => $row['district'],
      "address" => $row['address'],
      "profile_image" => $row['profile_image']
    ]
  ]);
} else {
  echo json_encode(["status" => "error", "message" => "User not found"]);
}

$stmt->close();
$conn->close();
