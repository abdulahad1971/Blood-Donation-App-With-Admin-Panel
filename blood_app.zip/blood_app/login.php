<?php
include 'db_connect.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $phone = $_POST['phone'];
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE phone = ?");
  $stmt->bind_param("s", $phone);
  $stmt->execute();
  $stmt->store_result();

  if ($stmt->num_rows > 0) {
    $stmt->bind_result($id, $name, $hashed_password);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
      $response['success'] = true;
      $response['message'] = "লগইন সফল";

      // লগইন সফল হলে ইউজারের ডেটা পাঠান
      $response['id'] = $id;
      $response['name'] = $name;
      $response['phone'] = $phone;
    } else {
      $response['success'] = false;
      $response['message'] = "পাসওয়ার্ড ভুল হয়েছে";
    }
  } else {
    $response['success'] = false;
    $response['message'] = "অকাউন্ট পাওয়া যায়নি";
  }
} else {
  $response['success'] = false;
  $response['message'] = "POST মেথড ব্যবহার করুন";
}

echo json_encode($response);
