<?php
header('Content-Type: application/json; charset=UTF-8');
include 'db_connect.php'; // DB কানেকশন

$sql = "SELECT id, name, phone, blood_group, district, address, profile_image FROM users WHERE is_donor = 1 ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

$response = array();

if ($result && mysqli_num_rows($result) > 0) {
    $response['success'] = true;
    $response['donors'] = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $response['success'] = false;
    $response['message'] = "কোনো রক্তদাতা পাওয়া যায়নি!";
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
