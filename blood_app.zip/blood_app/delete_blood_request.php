<?php
include 'db_connect.php';
header("Content-Type: application/json");

$response = array();

if (isset($_POST['id'])) {
  $id = intval($_POST['id']);

  // প্রথমে চেক করো রেকর্ড আছে কিনা
  $checkSql = "SELECT image FROM blood_requests WHERE id = $id";
  $result = mysqli_query($conn, $checkSql);

  if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $image = $row['image'];
    $image_path = "uploads/" . $image;

    // রেকর্ড ডিলিট
    $deleteSql = "DELETE FROM blood_requests WHERE id = $id";
    if (mysqli_query($conn, $deleteSql)) {

      // ছবিও ডিলিট করো
      if (file_exists($image_path)) {
        unlink($image_path);
      }

      $response['success'] = true;
      $response['message'] = "রক্তের অনুরোধ মুছে ফেলা হয়েছে।";
    } else {
      $response['success'] = false;
      $response['message'] = "মুছে ফেলতে সমস্যা হয়েছে: " . mysqli_error($conn);
    }
  } else {
    $response['success'] = false;
    $response['message'] = "রেকর্ড পাওয়া যায়নি।";
  }
} else {
  $response['success'] = false;
  $response['message'] = "ID প্রেরণ করুন।";
}

echo json_encode($response);
