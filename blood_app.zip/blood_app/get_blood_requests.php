<?php
include 'db_connect.php';
header("Content-Type: application/json");

$response = array();

$sql = "SELECT * FROM blood_requests ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
  $response['success'] = true;
  $response['requests'] = array();

  while ($row = mysqli_fetch_assoc($result)) {
    $request = array(
      'id' => $row['id'],
      'user_id' => $row['user_id'],
      'name' => $row['name'],
      'phone' => $row['phone'],
      'blood_group' => $row['blood_group'],
      'district' => $row['district'],
      'address' => $row['address'],
      'problem' => $row['problem'],
      'image' => $row['image'],
      'request_time' => $row['request_time']
    );

    array_push($response['requests'], $request);
  }
} else {
  $response['success'] = false;
  $response['message'] = "কোনো অনুরোধ পাওয়া যায়নি।";
}

echo json_encode($response);
