<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=UTF-8');
include 'db_connect.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn->set_charset("utf8mb4");

    $name       = $_POST['name'] ?? '';
    $phone      = $_POST['phone'] ?? '';
    $rawPass    = $_POST['password'] ?? '';
    $password   = !empty($rawPass) ? password_hash($rawPass, PASSWORD_DEFAULT) : '';
    $bloodGroup = $_POST['blood_group'] ?? '';
    $district   = $_POST['district'] ?? '';
    $address    = $_POST['address'] ?? '';
    $isDonor    = isset($_POST['is_donor']) && $_POST['is_donor'] == '1' ? 1 : 0;

    if (empty($name) || empty($phone) || empty($password) || empty($bloodGroup) || empty($district)) {
        $response['success'] = false;
        $response['message'] = "Required fields missing.";
        echo json_encode($response);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO users (name, phone, password, blood_group, district, address, is_donor) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $name, $phone, $password, $bloodGroup, $district, $address, $isDonor);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Signup successful.";
    } else {
        $response['success'] = false;
        if ($stmt->errno == 1062) {
            $response['message'] = "Phone number already exists.";
        } else {
            $response['message'] = "Signup failed: " . $stmt->error;
        }
    }

    $stmt->close();
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request.";
}

echo json_encode($response);
?>
